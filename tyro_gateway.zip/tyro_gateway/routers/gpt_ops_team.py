# tyro_gateway/routers/gpt_ops_team.py

from fastapi import APIRouter
from tyro_gateway.routers.writing import list_client_crm, add_client_crm
from tyro_gateway.routers.strategy import add_strategy, list_strategies

router = APIRouter()

# ✅ Client CRM — 查詢 / 新增
router.add_api_route("/client-crm", list_client_crm, methods=["GET"])
router.add_api_route("/add-client-crm", add_client_crm, methods=["POST"])

# ✅ Strategy — 查詢 / 新增
router.add_api_route("/strategies", list_strategies, methods=["GET"])
router.add_api_route("/add-strategy", add_strategy, methods=["POST"])
